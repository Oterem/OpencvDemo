import cv2
from diffimg import diff
from xlwt import Workbook
import os


#this function resizing the image and keeps on correct ratio
def make_image_even_dims(img):
    H, W = img.shape[:2]
    aspect = W / (H * 1.0)
    h = H * 0.5
    w = h * aspect
    resized = cv2.resize(img, (int(w), int(h)))
    return resized


def divideIntoTwo(image):
    height, width = image.shape[:2]
    start_row, start_col = int(0), int(0)
    # Let's get the ending pixel coordinates (bottom right of cropped top)
    end_row, end_col = int(height * .5), int(width)
    top_half = image[start_row:end_row, start_col:end_col]
    start_row, start_col = int(height * .5), int(0)
    # Let's get the ending pixel coordinates (bottom right of cropped bottom)
    end_row, end_col = int(height), int(width)
    bottom_half = image[start_row:end_row, start_col:end_col]
    return top_half, bottom_half


#This function rotates an image (in our case it gets the bottom half and rotate it 180 degrees
def rotate_image(image):
    (h, w) = image.shape[:2]
    center = (w / 2, h / 2)
    M = cv2.getRotationMatrix2D(center, 180, 1.0)
    rotated = cv2.warpAffine(image, M, (w, h))
    return rotated


'''
Flow of script:

Step 1: we specify our base working directory meaning where is folder that contains all the binary images(base_dir) - NOT the folder itself!
        Then we specify what is the name of the folder that contains all the binary images.
        
Step 2: We loop throught all the images, resizing them to be even dimensions in order to divide the image.
        We get two slices - bottom part and upper part. We then rotate bottom part 180 degrees, and compare
        these two parts using 'diff' function.

Step 3: After getting numeric number by 'diff' function, we store the value in Excel file along with
        the image correspondingly. Excel file name will be 'data.xls'.
          
'''
base_dir = 'C:\challenge\Assymetry'
name_of_binary_folder = 'ISIC-2017_Validation_Part1_GroundTruth'

source = base_dir+'\\'+name_of_binary_folder
top_dir = base_dir +'\Top'
bottom_dir = base_dir +'\Bottom'
wb = Workbook()
sheet1 = wb.add_sheet('Sheet 1')
names = os.listdir(source)
length = len(names)
i = 1
for img_name in names:
    img = cv2.imread(source + '\\' + img_name, 0)
    resized = make_image_even_dims(img)
    (top_half, bottom_half) = divideIntoTwo(resized)
    rot_bot = rotate_image(bottom_half)
    if not os.path.exists(top_dir):
        os.makedirs(top_dir)
    if not os.path.exists(bottom_dir):
        os.makedirs(bottom_dir)
    cv2.imwrite(top_dir+'\\'+img_name, top_half)
    cv2.imwrite(bottom_dir+'\\'+img_name, rot_bot)
    res = diff(top_dir+'\\'+img_name, bottom_dir+'\\'+img_name)
    sheet1.write(i, 0, img_name)
    sheet1.write(i, 1, res)
    i =i+1
    left = length-i
    print('left %d' % (left))

wb.save(base_dir+'\data.xls')





